
g_clubIdToSeenApplicants = {
	[782983] = {
		["Player-205-07AE0816"] = true,
		["Player-205-07B23829"] = true,
		["Player-205-078C9AF9"] = true,
	},
}
