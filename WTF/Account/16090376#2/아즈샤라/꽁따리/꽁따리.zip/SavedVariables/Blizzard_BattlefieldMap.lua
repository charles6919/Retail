
BattlefieldMapOptions = {
	["locked"] = false,
	["opacity"] = 0.7,
	["position"] = {
		["y"] = 483.0004577636719,
		["x"] = 1660.00048828125,
	},
	["showPlayers"] = true,
}
