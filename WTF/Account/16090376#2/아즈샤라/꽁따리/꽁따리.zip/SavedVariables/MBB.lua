
MBB_Exclude = {
}
MBB_Options = {
	["CollapseTimeout"] = 1,
	["AltExpandDirection"] = 4,
	["AttachToMinimap"] = 1,
	["ExpandDirection"] = 1,
	["MaxButtonsPerLine"] = 0,
	["ButtonPos"] = {
		-27.82582855224609, -- [1]
		-60.30900192260742, -- [2]
	},
	["DetachedButtonPos"] = "TOPLEFT",
}
