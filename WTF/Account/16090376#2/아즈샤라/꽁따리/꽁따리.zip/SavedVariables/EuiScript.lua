
TalentProfilesDB = nil
