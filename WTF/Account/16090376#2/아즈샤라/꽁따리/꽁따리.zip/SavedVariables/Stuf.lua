
StufCharDB = nil
