
MarkAssistantDB = {
	["blue"] = 0,
	["hideoncombat"] = false,
	["tooltips"] = true,
	["hide"] = false,
	["bgalpha"] = 0,
	["alpha"] = 0,
	["bggreen"] = 1,
	["green"] = 0,
	["locked"] = true,
	["bgred"] = 1,
	["bgblue"] = 1,
	["red"] = 0,
}
