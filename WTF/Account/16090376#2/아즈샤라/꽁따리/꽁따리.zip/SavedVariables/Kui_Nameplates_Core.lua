
KuiNameplatesCoreCharacterSaved = {
	["profile"] = "윈드라이드",
}
