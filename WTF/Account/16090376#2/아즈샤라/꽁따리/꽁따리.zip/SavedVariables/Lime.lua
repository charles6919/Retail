
limeCharDB = {
	["clickCasting"] = {
		{
		}, -- [1]
		{
		}, -- [2]
		{
		}, -- [3]
		{
		}, -- [4]
	},
	["class"] = "ROGUE",
	["spellTimer"] = {
		{
			["name"] = "57934",
			["scale"] = 1,
			["use"] = 1,
			["display"] = 1,
			["pos"] = "BOTTOMLEFT",
		}, -- [1]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "BOTTOM",
		}, -- [2]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "BOTTOMRIGHT",
		}, -- [3]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "LEFT",
		}, -- [4]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "RIGHT",
		}, -- [5]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "TOPLEFT",
		}, -- [6]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "TOP",
		}, -- [7]
		{
			["display"] = 1,
			["use"] = 0,
			["scale"] = 1,
			["pos"] = "TOPRIGHT",
		}, -- [8]
	},
	["classBuff2"] = {
	},
}
