
MSBTProfiles_SavedVarsPerChar = {
	["currentProfileName"] = "Default",
}
